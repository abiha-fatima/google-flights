// import axios from 'axios';

// export const fetchFlights = async (origin, destination, date) => {
//   try {
//     const response = await axios.get('https://sky-scrapper.p.rapidapi.com/flight/search', {
//       params: {
//         origin,
//         destination,
//         date,
//       },
//       headers: {
//         'X-RapidAPI-Host': 'sky-scrapper.p.rapidapi.com',
//         'X-RapidAPI-Key': '1381a56970msha0a2ecf57c33a98p123ef9jsnccde85480b30',  // Replace with your actual API key
//       },
//     });
//     return response.data;
//   } catch (error) {
//     console.error("Error fetching flight data: ", error);
//     throw error;
//   }
// };






import axios from 'axios';

// Base URL and Headers for Sky-Scrapper API
const BASE_URL = 'https://sky-scrapper.p.rapidapi.com';
const HEADERS = {
  'X-RapidAPI-Host': 'sky-scrapper.p.rapidapi.com',
  'X-RapidAPI-Key': `${process.env.REACT_APP_RAPIDAPI_KEY}`, 
};

// Fetch nearby airports based on latitude and longitude
export const getNearByAirports = async (lat, lng) => {
    try {
      const response = await axios.get(`${BASE_URL}/api/v1/flights/getNearByAirports`, {
        params: { lat, lng, locale: 'en-US' },
        headers: HEADERS,
      });
      return response.data.data.nearby; // Return nearby airports data
    } catch (error) {
      console.error("Error fetching nearby airports: ", error);
      throw error;
    }
  };
  
  // Search airports based on a query (e.g., 'new')
  export const searchAirports = async (query) => {
    try {
      const response = await axios.get(`${BASE_URL}/api/v1/flights/searchAirport`, {
        params: { query, locale: 'en-US' },
        headers: HEADERS,
      });
      return response.data.data; // Return searched airports data
    } catch (error) {
      console.error("Error searching airports: ", error);
      throw error;
    }
  };


  export const searchFlights = async (originSkyId, destinationSkyId, originEntityId, destinationEntityId, date, adults = 1, cabinClass) => {
    const options = {
      method: 'GET',
      url: 'https://sky-scrapper.p.rapidapi.com/api/v1/flights/searchFlights',
      params: {
        originSkyId: originSkyId,
        destinationSkyId: destinationSkyId,
        originEntityId: originEntityId,  
        destinationEntityId: destinationEntityId, 
        date: date,
        cabinClass: cabinClass,
        adults: adults,
        sortBy: 'best',
        currency: 'USD',
        market: 'en-US',
        countryCode: 'US',
      },
      headers: HEADERS,
    };
  
    try {
      const response = await axios.request(options);
      return response.data; // Returning the data to be processed in the calling component
    } catch (error) {
      console.error(error);
      return { error: 'Failed to fetch flight data' };
    }
  };





