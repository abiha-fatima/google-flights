import React from 'react';
import { Autocomplete, TextField, CircularProgress } from '@mui/material';

const AirportDropdown = ({ label, value, onChange, handleAirportSearch, loading, nearbyAirports, excludeSkyId }) => (
  <Autocomplete
    value={value && value.name ? value : null} 
    onChange={(event, newValue) => onChange(event, newValue)} 
    onInputChange={(event, newInputValue) => handleAirportSearch(event)} 
    options={nearbyAirports
      .filter(airport => airport.navigation.relevantFlightParams.skyId !== excludeSkyId)  
      .map(airport => ({
        label: `${airport.presentation.title} (${airport.navigation.relevantFlightParams.skyId})`,
        value: airport 
      }))
    }
    getOptionLabel={(option) => option.label} 
    renderInput={(params) => (
      <TextField 
        {...params} 
        label={label} 
        fullWidth 
        variant="outlined"
        InputProps={{
          ...params.InputProps,
          endAdornment: loading ? <CircularProgress color="inherit" size={20} /> : null,
        }}
      />
    )}
  />
);

export default AirportDropdown;





