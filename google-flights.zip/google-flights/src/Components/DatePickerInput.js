import React, { useState } from 'react';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TextField, FormControl, InputLabel, Select, MenuItem, Typography, Grid, Box } from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

export const DatePickerInput = ({ departureDate, setDepartureDate, returnDate, setReturnDate }) => {
  const [tripType, setTripType] = useState('round-trip'); 

  const handleDepartureDateChange = (newValue) => {
    setDepartureDate(newValue);
    if (returnDate && newValue > returnDate) {
      setReturnDate(null);
    }
  };

  const handleReturnDateChange = (newValue) => {
    setReturnDate(newValue);
  };

  const handleTripTypeChange = (event) => {
    setTripType(event.target.value);
    if (event.target.value === 'one-way' || event.target.value === 'multi-city') {
      setReturnDate(null); 
    }
    else{
      setReturnDate(new Date());
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={4}>
          <Box>
            <Typography variant="body1">Trip Type</Typography>
            <FormControl fullWidth>
              <Select
                labelId="trip-type-label"
                value={tripType}
                onChange={handleTripTypeChange}
              >
                <MenuItem value="round-trip">Round Trip</MenuItem>
                <MenuItem value="one-way">One-Way</MenuItem>
                <MenuItem value="multi-city">Multi-City</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </Grid>

        <Grid item xs={12} sm={4}>
          <Box>
            <Typography variant="body1">Departure Date</Typography>
            <DatePicker
              value={departureDate}
              onChange={handleDepartureDateChange}
              renderInput={(params) => <TextField {...params} fullWidth />}
            />
          </Box>
        </Grid>

        <Grid item xs={12} sm={4}>
          <Box>
            <Typography variant="body1">Return Date</Typography>
            <DatePicker
              value={returnDate}
              onChange={handleReturnDateChange}
              renderInput={(params) => <TextField {...params} fullWidth />}
              minDate={departureDate} 
              disabled={tripType === 'one-way'} 
            />
          </Box>
        </Grid>
      </Grid>
    </LocalizationProvider>
  );
};

export default DatePickerInput;


