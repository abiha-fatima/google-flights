import React, { useState } from 'react';
import { TextField, Autocomplete, CircularProgress, Grid } from '@mui/material';
import { searchAirports } from '../utils/api';

const FlightSearch = (props) => {
  const [originLoading, setOriginLoading] = useState(false);
  const [destinationLoading, setDestinationLoading] = useState(false);

  const handleAirportSearch = async (newInputValue, type) => {
    const query = newInputValue;
    if (query) {
      if (type === 'origin') {
        setOriginLoading(true);
      } else {
        setDestinationLoading(true);
      }
      try {
        const searchData = await searchAirports(query);
        if (searchData && searchData.length > 0) {
          props.setNearbyAirports(searchData);
        } else {
          // props.setError('No airports found');
        }
      } catch (err) {
        props.setError('Failed to search airports');
      } finally {
        if (type === 'origin') {
          setOriginLoading(false);
        } else {
          setDestinationLoading(false);
        }
      }
    } else {
      if (type === 'origin') {
        setOriginLoading(false);
      } else {
        setDestinationLoading(false);
      }
    }
  };

  const handleAirportSelect = (event, value, type) => {
    if (!value) return;

    const selectedAirport = value.airportObject;
    const name = selectedAirport.presentation?.title || '';
    const skyId = selectedAirport.navigation?.relevantFlightParams?.skyId || '';
    const entityId = selectedAirport.navigation?.entityId || '';

    if (name && skyId) {
      if (type === 'origin') {
        props.setOrigin({ name, skyId, entityId });
      } else {
        props.setDestination({ name, skyId, entityId });
      }
    }
  };

  const filterAirports = (airports, excludeSkyId) => {
    return airports.filter(airport => airport.navigation?.relevantFlightParams?.skyId !== excludeSkyId);
  };

  return (
    <>
      {/* Grid container for aligning Origin and Destination on the same line */}
      <Grid container spacing={3}>
        
        {/* Origin Autocomplete */}
        <Grid item xs={12} sm={6}>
          <Autocomplete
            value={props.origin ? {
              label: `${props.origin.name} (${props.origin.skyId})`,
              airportObject: props.origin
            } : null}
            onChange={(event, newValue) => {
              handleAirportSelect(event, newValue, 'origin');
            }}
            onInputChange={(event, newInputValue) => handleAirportSearch(newInputValue, 'origin')}
            options={props.nearbyAirports.map(airport => ({
              label: `${airport.presentation?.title} (${airport.navigation?.relevantFlightParams?.skyId})`,
              skyId: airport.navigation?.relevantFlightParams?.skyId,
              airportObject: airport
            }))}
            getOptionLabel={(option) => option.label}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Origin"
                fullWidth
                InputProps={{
                  ...params.InputProps,
                  endAdornment: (
                    <>
                      {originLoading ? <CircularProgress color="inherit" size={20} /> : null}
                      {params.InputProps.endAdornment}
                    </>
                  ),
                }}
              />
            )}
            loading={props.loading || originLoading}
          />
        </Grid>

        {/* Destination Autocomplete */}
        <Grid item xs={12} sm={6}>
          <Autocomplete
            value={props.destination ? {
              label: `${props.destination.name} (${props.destination.skyId})`,
              airportObject: props.destination
            } : null}
            onChange={(event, newValue) => {
              handleAirportSelect(event, newValue, 'destination');
            }}
            onInputChange={(event, newInputValue) => handleAirportSearch(newInputValue, 'destination')}
            options={filterAirports(props.nearbyAirports, props.origin?.skyId).map(airport => ({
              label: `${airport.presentation?.title} (${airport.navigation?.relevantFlightParams?.skyId})`,
              skyId: airport.navigation?.relevantFlightParams?.skyId,
              airportObject: airport
            }))}
            getOptionLabel={(option) => option.label}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Destination"
                fullWidth
                InputProps={{
                  ...params.InputProps,
                  endAdornment: (
                    <>
                      {destinationLoading ? <CircularProgress color="inherit" size={20} /> : null}
                      {params.InputProps.endAdornment}
                    </>
                  ),
                }}
              />
            )}
            loading={props.loading || destinationLoading}
          />
        </Grid>
        
      </Grid>
    </>
  );
};

export default FlightSearch;















