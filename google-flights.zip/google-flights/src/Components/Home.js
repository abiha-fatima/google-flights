import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, CircularProgress, Select, MenuItem, FormControl, IconButton, Paper, Grid } from '@mui/material';
import FlightSearch from './FlightSearch'; 
import { DatePickerInput } from './DatePickerInput'; 
import { getNearByAirports, searchFlights } from '../utils/api'; 
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import CommonTable from './CommonTable'; 
import { format, set } from 'date-fns';
import googleFlights from "../Components/images/googleFlights.png"; // Import the local image

const Home = () => {
  const [origin, setOrigin] = useState(null);
  const [destination, setDestination] = useState(null);
  const [nearbyAirports, setNearbyAirports] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);
  const [departureDate, setDepartureDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(new Date());
  const [classType, setClassType] = useState("economy");
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [tableData, setTableData] = useState([]);

  const columns = [
    { 
      name: "logo", 
      label: " ",
      options: {
        customBodyRender: (value) => (
          <img 
            src={value} 
            alt="" 
            style={{ 
              width: "30px", 
              height: "30px", 
              objectFit: "contain", 
              marginRight: "-20px"  
            }} 
          />
        ),
        filter: false,
        sort: false
      }
    },
    { name: "airline", label: "Airline" },
    { name: "flightNumber", label: "Flight Number", options: { filter: false, sort: false } },
    { name: "departureTime", label: "Departure Time", options: { filter: false, sort: true } },
    { name: "arrivalTime", label: "Arrival Time", options: { filter: false, sort: true } },
    { name: "price", label: "Price (USD)", options: { filter: false, sort: true } },
    { name: "duration", label: "Duration", options: { filter: false, sort: false } },
    { name: "stops", label: "Stops" },
  ];

  // Fetch user's location for nearby airports
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setLat(position.coords.latitude);
        setLng(position.coords.longitude);
      });
    } else {
      setLat(25.276987); // Default location
      setLng(55.296249);
    }
  }, []);

  useEffect(() => {
    if (lat && lng) {
      setLoading(true);
      getNearByAirports(lat, lng)
        .then((data) => {
          setNearbyAirports(data);
          setLoading(false);
        })
        .catch((err) => {
          console.log("Error fetching near-by airports");
          setLoading(false);
        });
    }
  }, [lat, lng]);

  const handleIncrement = (type) => {
    if (type === 'adults') setAdults(adults + 1);
    if (type === 'children') setChildren(children + 1);
  };

  const handleDecrement = (type) => {
    if (type === 'adults' && adults > 1) setAdults(adults - 1);
    if (type === 'children' && children > 0) setChildren(children - 1);
  };

  const handleSearch = () => {
    const formattedDepartureDate = format(departureDate, 'yyyy-MM-dd');
    setLoading(true);

    searchFlights(
      origin.skyId, 
      destination.skyId, 
      origin.entityId,
      destination.entityId,
      formattedDepartureDate, 
      adults, 
      classType
    )
    .then((response) => {
      const tableData = response.data.itineraries.map((itinerary) => {
        const firstLeg = itinerary.legs[0];
        const airline = firstLeg.carriers.marketing[0].name;
        const flightNumber = firstLeg.segments[0].flightNumber;
        const departureTime = format(new Date(firstLeg.departure), 'hh:mm a');
        const arrivalTime = format(new Date(firstLeg.arrival), 'hh:mm a');
        const price = itinerary.price.formatted;
        const duration = convertToHoursMinutes(firstLeg.durationInMinutes);
        const logo = firstLeg.carriers.marketing[0].logoUrl;
        const stops = firstLeg.stopCount;

        return {
          airline,
          flightNumber,
          departureTime,
          arrivalTime,
          price,
          duration,
          logo,
          stops
        };
      });

      setTableData(tableData);
      setLoading(false);
    })
    .catch((err) => {
      setError('Failed to fetch flight data');
      setLoading(false);
    });
  };


  const clearData = () => {
    setOrigin(null);
    setDestination(null);
    setDepartureDate(new Date());
    setReturnDate(null);
    setAdults(1);
    setChildren(0);
    setClassType('economy');
    setTableData([]);
    if (lat && lng) {
      
      getNearByAirports(lat, lng)
        .then((data) => {
          setNearbyAirports(data);
          
        })
        .catch((err) => {
          setError('Failed to fetch nearby airports');
         
        });
    }
  };

  const convertToHoursMinutes = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours} hrs ${mins} mins`;
  };

  return (
    <Box sx={{ padding: 3 }}>
      <Box 
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: '250px',  
                width: '100%',
                background: `url(${googleFlights}) no-repeat center center`,
                backgroundSize: 'cover',  
                zIndex: -1,
              }}
            ></Box>


<Typography
        variant="h2"
        sx={{
          fontFamily: "'Product Sans', sans-serif",
          fontWeight: 400,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "50px", 
          letterSpacing: "0.5px",
          fontSize: "35px",
          color: "#5F6368",

          position: "relative",
          top: "140px", // Moves it 50px down
          marginTop: '50px',

          "& span:first-of-type": { color: "#4285F4" }, // Blue
          "& span:nth-of-type(2)": { color: "#EA4335" }, // Red
          "& span:nth-of-type(3)": { color: "#FBBC05" }, // Yellow
          "& span:nth-of-type(4)": { color: "#34A853" }, // Green
        }}
      >
        <span>G</span>
        <span>o</span>
        <span>o</span>
        <span>g</span>
        <span>l</span>
        <span>e</span> &nbsp;
        <span>Flights</span>
      </Typography>


      
      <Box 
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          padding: '0px 0px',
          marginTop: '150px',
        }}
      >
        <Box sx={{ width: '100%', maxWidth: '1200px' }}>
         
          <FlightSearch
            loading={loading}
            nearbyAirports={nearbyAirports}
            setNearbyAirports={setNearbyAirports}
            setError={setError}
            origin={origin}
            setOrigin={setOrigin}
            destination={destination}
            setDestination={setDestination}
          />

          {error && <Typography color="error">{error}</Typography>}

          <Grid container spacing={3} style={{marginBottom: '50px'}}>
            <Grid item xs={12} sm={6}>
              <Box sx={{ marginTop: 2 }}>
                <DatePickerInput
                  departureDate={departureDate}
                  setDepartureDate={setDepartureDate}
                  returnDate={returnDate}
                  setReturnDate={setReturnDate}
                />
              </Box>
            </Grid>

          
            <Grid item xs={8} sm={2}>
              <Box sx={{ marginTop: 2 }}>
                <Typography variant="body1">Class</Typography>
                <FormControl fullWidth>
                  <Select
                    labelId="class-label"
                    value={classType}
                    label="Class"
                    onChange={(e) => setClassType(e.target.value)}
                    sx={{ width: '100%' }}
                  >
                    <MenuItem value="economy">Economy</MenuItem>
                    <MenuItem value="business">Business</MenuItem>
                    <MenuItem value="first-class">First Class</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            </Grid>

           
            <Grid item xs={8} sm={2}>
              <Box sx={{ marginTop: 2 }}>
                <Typography variant="body1">Adults</Typography>
                <Paper sx={{ padding: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                  <IconButton onClick={() => handleDecrement('adults')}><RemoveIcon /></IconButton>
                  <Typography variant="body1">{adults}</Typography>
                  <IconButton onClick={() => handleIncrement('adults')}><AddIcon /></IconButton>
                </Paper>
              </Box>
            </Grid>

            
            <Grid item xs={8} sm={2}>
              <Box sx={{ marginTop: 2, marginLeft: '10px' }}>
                <Typography variant="body1">Children</Typography>
                <Paper sx={{ padding: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                  <IconButton onClick={() => handleDecrement('children')}><RemoveIcon /></IconButton>
                  <Typography variant="body1">{children}</Typography>
                  <IconButton onClick={() => handleIncrement('children')}><AddIcon /></IconButton>
                </Paper>
              </Box>
            </Grid>

            
          </Grid>

          <Grid container spacing={1} style={{marginBottom: '10px'}}>
          <Grid item xs={8} sm={2}>
              <Box sx={{ marginTop: '-30px', paddingLeft: '5px' }}>
                <Button variant="contained" color="primary" onClick={handleSearch}>
                  Search Flights
                </Button>
              </Box>
            </Grid>

            <Grid item xs={8} sm={2}>
              <Box sx={{ marginTop: '-30px'}} >
                <Button variant="outlined" color="primary" onClick={clearData}>
                  Clear
                </Button>
              </Box>
            </Grid>

            </Grid>

          <Box sx={{ maxHeight: '1000px', overflowY: 'auto' }}>
            {loading ? (
              <CircularProgress />
            ) : (
              <CommonTable data={tableData} columns={columns} />
            )}
          </Box>

        </Box>
      </Box>
    </Box>
  );
};

export default Home;
