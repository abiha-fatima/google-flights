import MUIDataTable from "mui-datatables";
import { createTheme, ThemeProvider } from '@mui/material/styles';

const commonTable = (props) => {

    const getMuiTheme = () =>
        createTheme({
            typography: {
                "fontFamily": 'Inter, - apple - system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans- serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
                       
                "fontSize": 13,
                "fontWeightLight": 300,
                "fontWeightRegular": 400,
                "fontWeightMedium": 500,
            },
            components: {
   
                MUIDataTableBody: {
                    styleOverrides: {
                        emptyTitle: {
                        }
                    }
                },
                MuiToolbar: {
                    styleOverrides: {
                        regular: {
                            
                            height: "32px",
                            minHeight: "32px",
                            "@media (min-width: 600px)": {
                                minHeight: "32px",
                            },
                        },
                    },
                }, 
                MuiTableCellBody: {
                    fontfamily: 'Inter, - apple - system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans- serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',

                    fontweight: '500'
                },
                MuiTableCell: {
                    styleOverrides: {
                        head: {
                            backgroundColor: '#f5f6f8',
                            color: 'black',
                            padding: '0'
                           
                        },
                        body: {
                        },
                        root: {
                            padding: '7px',
                            overflowWrap:'anywhere'
                            
                        },
                        footer: {
                            padding: '0'
                        }
                    },
                },
                MuiTablePagination: {
                    styleOverrides: {
                        selectLabel: {
                            margin: '0'
                        },
                        displayedRows: {
                            margin: '0'
                        }
                    }
                },
                MuiTableSortLabel: {
                    styleOverrides: {
                        root: {
                            "&.Mui-active": {
                                "&&": {
                                    "& * ": {
                                        color: "black",

                                    }
                                }
                            }
                        }
                    }
                },
                MUIDataTableHeadCell: {
                    styleOverrides: {
                        sortActive: {
                            color: 'black',
                            
                        }
                    }
                }
            }
        });

    const baseOptions = {
        search: true,
        print: true,
        viewColumns: false,
        filter: true,
        filterType: "multiselect",
        responsive: "standard",
        tableBodyMaxHeight: "",
        selectableRows: "none",        
        rowsPerPageOptions: props.limt === 0 ? [] : undefined,
        rowsPerPage: props.limt === 0 ? 1000 : undefined,
        textLabels: {
            body: {
                noMatch:'No data available',
            }
        },
    };
    const options = {
        ...baseOptions,
        download: props.download !== undefined ? props.download : baseOptions.download,
    };    
    return (

        <ThemeProvider theme={getMuiTheme()}>
             <MUIDataTable title={props.title} data={props.data} columns={props.columns} options={options} />
        </ThemeProvider>
    )
}
export default commonTable;